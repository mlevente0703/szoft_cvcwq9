﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mintazh
{
    public partial class EditedForm1 : Form
    {
        public Futok EditedFutok;
        public EditedForm1()
        {
            InitializeComponent();
        }

        private void EditedForm1_Load(object sender, EventArgs e)
        {
            futokBindingSource.DataSource = EditedFutok;
        }
    }
}
